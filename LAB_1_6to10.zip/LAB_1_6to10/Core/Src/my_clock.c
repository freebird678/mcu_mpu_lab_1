#include "my_clock.h"
#include "stm32f103x6.h"
#include "stm32f1xx_hal_gpio.h"

const uint16_t clock_pin[12] = {0x8000, 0x0010, 0x0020, 0x0040, 0x0080, 0x0100,
                                0x0200, 0x0400, 0x0800, 0x1000, 0x2000, 0x4000};
void clearAllClock() {
  for (int i = 0; i < 12; i++)
    HAL_GPIO_WritePin(GPIOA, clock_pin[i], 0);
}

void setNumberOnClock(int num) {
  if (num < 0 || num > 11)
    return;
  HAL_GPIO_WritePin(GPIOA, clock_pin[num], 1);
}

void clearNumberOnClock(int num) {
  if (num < 0 || num > 11)
    return;
  HAL_GPIO_WritePin(GPIOA, clock_pin[num], 0);
}