/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins
*/
void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, num1_Pin|num2_Pin|num3_Pin|num4_Pin
                          |num5_Pin|num6_Pin|num7_Pin|num8_Pin
                          |num9_Pin|num10_Pin|num11_Pin|num12_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : num1_Pin num2_Pin num3_Pin num4_Pin
                           num5_Pin num6_Pin num7_Pin num8_Pin
                           num9_Pin num10_Pin num11_Pin num12_Pin */
  GPIO_InitStruct.Pin = num1_Pin|num2_Pin|num3_Pin|num4_Pin
                          |num5_Pin|num6_Pin|num7_Pin|num8_Pin
                          |num9_Pin|num10_Pin|num11_Pin|num12_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 2 */

/* USER CODE END 2 */
