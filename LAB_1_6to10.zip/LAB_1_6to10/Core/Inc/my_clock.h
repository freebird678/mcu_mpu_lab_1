#ifndef MY_CLOCK_H
#define MY_CLOCK_H

#include "main.h"
#include <stdint.h>

extern const uint16_t clock_pin[12];
// based on definitions of the gpio pins
void clearAllClock();
void setNumberOnClock(int num);
void clearNumberOnClock(int num);

#endif