#ifndef EXERCISES_H
#define EXERCISES_H

void two_leds_switching();
void traffic_light_delay();
void intersection_traffic();
void display7SEG(int num);
void intersection_with_7seg();

#endif