/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define led_red_Pin GPIO_PIN_5
#define led_red_GPIO_Port GPIOA
#define led_yellow_Pin GPIO_PIN_6
#define led_yellow_GPIO_Port GPIOA
#define led_green_Pin GPIO_PIN_7
#define led_green_GPIO_Port GPIOA
#define _7seg_A_Pin GPIO_PIN_0
#define _7seg_A_GPIO_Port GPIOB
#define _7seg_B_Pin GPIO_PIN_1
#define _7seg_B_GPIO_Port GPIOB
#define _7seg_C_Pin GPIO_PIN_2
#define _7seg_C_GPIO_Port GPIOB
#define _7seg_otherD_Pin GPIO_PIN_10
#define _7seg_otherD_GPIO_Port GPIOB
#define _7seg_otherE_Pin GPIO_PIN_11
#define _7seg_otherE_GPIO_Port GPIOB
#define _7seg_otherF_Pin GPIO_PIN_12
#define _7seg_otherF_GPIO_Port GPIOB
#define _7seg_otherG_Pin GPIO_PIN_13
#define _7seg_otherG_GPIO_Port GPIOB
#define led_other_red_Pin GPIO_PIN_8
#define led_other_red_GPIO_Port GPIOA
#define led_other_yellow_Pin GPIO_PIN_9
#define led_other_yellow_GPIO_Port GPIOA
#define led_other_green_Pin GPIO_PIN_10
#define led_other_green_GPIO_Port GPIOA
#define _7seg_D_Pin GPIO_PIN_3
#define _7seg_D_GPIO_Port GPIOB
#define _7seg_E_Pin GPIO_PIN_4
#define _7seg_E_GPIO_Port GPIOB
#define _7seg_F_Pin GPIO_PIN_5
#define _7seg_F_GPIO_Port GPIOB
#define _7seg_G_Pin GPIO_PIN_6
#define _7seg_G_GPIO_Port GPIOB
#define _7seg_otherA_Pin GPIO_PIN_7
#define _7seg_otherA_GPIO_Port GPIOB
#define _7seg_otherB_Pin GPIO_PIN_8
#define _7seg_otherB_GPIO_Port GPIOB
#define _7seg_otherC_Pin GPIO_PIN_9
#define _7seg_otherC_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
