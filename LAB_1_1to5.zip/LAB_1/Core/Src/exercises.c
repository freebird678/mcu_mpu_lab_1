#include "exercises.h"
#include "main.h"
#include "stm32f1xx_hal.h"
#include "stm32f1xx_hal_gpio.h"
#include <stdint.h>

void two_leds_switching() {
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 0);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 1);
  HAL_Delay(2000);
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 1);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 0);
  HAL_Delay(2000);
}

void traffic_light_delay() {
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 1);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 0);
  HAL_Delay(5000);
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 0);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 1);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 0);
  HAL_Delay(2000);
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 0);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 1);
  HAL_Delay(3000);
}

void intersection_traffic() {
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 1);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 0);
  HAL_GPIO_WritePin(led_other_red_GPIO_Port, led_other_red_Pin, 0);
  HAL_GPIO_WritePin(led_other_yellow_GPIO_Port, led_other_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_other_green_GPIO_Port, led_other_green_Pin, 1);
  HAL_Delay(3000);
  HAL_GPIO_WritePin(led_other_red_GPIO_Port, led_other_red_Pin, 0);
  HAL_GPIO_WritePin(led_other_yellow_GPIO_Port, led_other_yellow_Pin, 1);
  HAL_GPIO_WritePin(led_other_green_GPIO_Port, led_other_green_Pin, 0);
  HAL_Delay(2000);
  HAL_GPIO_WritePin(led_other_red_GPIO_Port, led_other_red_Pin, 1);
  HAL_GPIO_WritePin(led_other_yellow_GPIO_Port, led_other_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_other_green_GPIO_Port, led_other_green_Pin, 0);
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 0);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 1);
  HAL_Delay(3000);
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 0);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 1);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 0);
  HAL_Delay(2000);
}

void display7SEG(int num) {
  uint8_t _7segMap[10] = {0x81, 0xcf, 0x92, 0x86, 0xcc,
                          0xa4, 0xa0, 0x8f, 0x80, 0x84};
  HAL_GPIO_WritePin(_7seg_A_GPIO_Port, _7seg_A_Pin,
                    (_7segMap[num] & 0x40) >> 6);
  HAL_GPIO_WritePin(_7seg_B_GPIO_Port, _7seg_B_Pin,
                    (_7segMap[num] & 0x20) >> 5);
  HAL_GPIO_WritePin(_7seg_C_GPIO_Port, _7seg_C_Pin,
                    (_7segMap[num] & 0x10) >> 4);
  HAL_GPIO_WritePin(_7seg_D_GPIO_Port, _7seg_D_Pin,
                    (_7segMap[num] & 0x08) >> 3);
  HAL_GPIO_WritePin(_7seg_E_GPIO_Port, _7seg_E_Pin,
                    (_7segMap[num] & 0x04) >> 2);
  HAL_GPIO_WritePin(_7seg_F_GPIO_Port, _7seg_F_Pin,
                    (_7segMap[num] & 0x02) >> 1);
  HAL_GPIO_WritePin(_7seg_G_GPIO_Port, _7seg_G_Pin, _7segMap[num] & 0x01);
  HAL_Delay(1000);
}

void intersection_with_7seg() {
  // There is one 7-segment display in this system, thus it counts for one road
  // each iteration. Red light on one road
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 1);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 0);
  // Green light on the intersecting road
  HAL_GPIO_WritePin(led_other_red_GPIO_Port, led_other_red_Pin, 0);
  HAL_GPIO_WritePin(led_other_yellow_GPIO_Port, led_other_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_other_green_GPIO_Port, led_other_green_Pin, 1);
  for (int i = 5; i > 2; i--)
    // Counter starts counting from 5 to represent the timer of the red light
    display7SEG(i);
  HAL_GPIO_WritePin(led_other_red_GPIO_Port, led_other_red_Pin, 0);
  HAL_GPIO_WritePin(led_other_yellow_GPIO_Port, led_other_yellow_Pin, 1);
  HAL_GPIO_WritePin(led_other_green_GPIO_Port, led_other_green_Pin, 0);
  for (int i = 2; i > 0; i--)
    // Resume counting from 2
    display7SEG(i);
  HAL_GPIO_WritePin(led_other_red_GPIO_Port, led_other_red_Pin, 1);
  HAL_GPIO_WritePin(led_other_yellow_GPIO_Port, led_other_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_other_green_GPIO_Port, led_other_green_Pin, 0);
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 0);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 0);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 1);
  // Counter switches to counting for the intersecting road.
  for (int i = 5; i > 2; i--)
    display7SEG(i);
  HAL_GPIO_WritePin(led_red_GPIO_Port, led_red_Pin, 0);
  HAL_GPIO_WritePin(led_yellow_GPIO_Port, led_yellow_Pin, 1);
  HAL_GPIO_WritePin(led_green_GPIO_Port, led_green_Pin, 0);
  for (int i = 2; i > 0; i--)
    display7SEG(i);
}